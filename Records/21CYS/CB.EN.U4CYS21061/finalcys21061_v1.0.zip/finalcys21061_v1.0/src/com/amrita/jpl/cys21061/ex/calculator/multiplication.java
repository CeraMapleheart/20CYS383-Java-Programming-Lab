package com.amrita.jpl.cys21061.ex.calculator;
import java.util.Scanner;
/**
 * @author Roshni-CYS21061
 */
public class multiplication {
    public static void main(String[] args) {
        /**
         * multiplies two integers
         * @param x first int
         * @param y second int
         */
        int x=50;
        int y=60;
        int product= x*y;
        System.out.println(product);
    }
}


package com.amrita.jpl.cys21061.ex.calculator;
import java.util.Scanner;
/**
 * @author Roshni-CYS21061
 */

public class addition {
    public static void main(String[] args) {
        /**
         * adds two integers
         * @param x first int
         * @param y second int
         */
        int x=50;
        int y=60;
        int sum= x+y;
        System.out.println(sum);
    }
}


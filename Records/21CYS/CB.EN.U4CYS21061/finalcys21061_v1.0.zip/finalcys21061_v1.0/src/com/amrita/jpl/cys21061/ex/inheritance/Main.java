package com.amrita.jpl.cys21061.ex.inheritance;
/**
 * @author Roshni-CYS21061
 */
class Vehicle {
    /**
     * parent class member function and variable
     */
    public void start() { }
    public void stop() { }
    int run_status = 0;
}

class Car extends Vehicle {
    /**
     * child class member functions
     */
    public void Car(){
        /**
         * @param YearC
         * @param ModelName
         * @param Num_of_Wheels
         */
        str ModelName = scanner.nextStr();
        int YearC = scanner.nextInt();
        int Num_of_Wheels = scanner.nextInt();
    }
    public void drive() {
        /**
         * @param Gear
         */
        int Gear = scanner.nextInt();
    }
    public void start() {
        System.out.println("Car Instantiated with Parameter ",ModelName,", ",YearC", ",Num_of_Wheels);
        System.out.println("[Vehicle] started.");
    }
    public void start() {
        System.out.println("Driving the car in gear position: ", gear);
        System.out.println("[Vehicle] stopped.");
    }
}

class Bike extends Vehicle {
    /**
     * child class member functions
     */
    public void Bike(){
        /**
         * @param YearB
         * @param BrandName
         * @param Num_of_Gears
         */
        str BrandName = scanner.nextStr();
        int YearB = scanner.nextInt();
        int Num_of_Gears = scanner.nextInt();
    }
    public void pedal() {
        /**
         * @param PedalSpeed
         */
        int PedalSpeed = scanner.nextInt();
    }
    public void start() {
        System.out.println("Bike Instantiated with Parameter ",BrandName,", ",YearB,", ",Num_of_Gears);
        System.out.println("[Vehicle] started.");
    }
    public void stop() {
        System.out.println("Pedaling the bike at speed: ", PedalSpeed);
        System.out.println("[Vehicle] stopped.");
    }
}

public class Main {
    public static void main(String[] args) {
        Car C = new Car();
        C.start();
        C.drive();
        C.stop();

        Bike B = new Bike();
        B.start();
        B.pedal();
        B.stop();
    }
}
package com.amrita.jpl.cys21061.p1;

import java.util.Scanner;

/**
 * @author Roshni-CYS21061
 */
public class Main {
    int choice, check;

    /**
     * taking input integer
     *
     * @param a input integer
     */
    public  int fact(int a) {
        int i=0;
        for(i=1; i<a+1; i++){
            i *= i;
        }
        return i;
    }
    public int sum_n_no(int a) {
        int i=0;
        for(i=1; i<a+1; i++){
            i *= i;
        }
        return(i);
    }

    public int prime_test(int a) {
        int i=1;
        for(i=2; i< (a/2+1); i++) {
            if (a % i == 0) {
                return 1;
            }
        }
        return 0;
    }
    public int fibo(int a1) {
        if((a1==0||a1==1)) {
            System.out.println(a1);
        }
        else {
            System.out.println(fibo(a1-1) + fibo(a1-2));
        }
    }
    /**
     * main function
     * @param args default argument
     * @return output integer
     */
    public static int main(String[] args) {
        System.out.println("Menu:");
        System.out.println("1. Factorial (fact)");
        System.out.println("2. Fibonacci (fibo)");
        System.out.println("3. The sum of n numbers (sum_n_no");
        System.out.println("4. Prime Test (prime_test)");

        Scanner choice = new Scanner(System.in);
        Integer name = choice.nextInt();

        Scanner check = new Scanner(System.in);
        Integer name1 = check.nextInt();

        Main obje = new Main();

        switch (choice) {
            case 1:
                obje.fact(check);
                break;
            case 2:
                obje.fibo(check);
                break;
            case 3:
                obje.sum_n_no(check);
                break;
            case 4:
                obje.prime_test(check);
                break;
        }
        return 0;
    }
}


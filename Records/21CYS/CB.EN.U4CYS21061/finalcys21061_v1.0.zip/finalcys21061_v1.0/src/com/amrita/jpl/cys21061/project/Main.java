package com.amrita.jpl.cys21061.project;

public class Main {
    public static void main(String[] args) {
        UniCyMeGUI gui = new UniCyMeGUI();
    }
}
